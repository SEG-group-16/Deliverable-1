package com.example.fika;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FikaApplicationTests {

	@Test
	void contextLoads() {
	}

}
